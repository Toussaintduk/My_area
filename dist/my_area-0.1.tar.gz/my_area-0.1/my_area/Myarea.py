def calc_area(l,w):
  if l<=0 and w<=0:
    print("Invalid input the length and width must be postive")
    return None
  return l*w